package dao;

import model.KhachHang;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class KhachHangDAO {

    public KhachHangDAO() {
        createTableIfNotExists();
    }

    // Tạo bảng nếu chưa tồn tại
    private void createTableIfNotExists() {
        String sql = "CREATE TABLE IF NOT EXISTS khach_hang (" +
                     "ma_kh INTEGER PRIMARY KEY AUTOINCREMENT," +
                     "ho_ten TEXT NOT NULL," +
                     "so_dt TEXT NOT NULL," +
                     "tien_co REAL NOT NULL)";
        try (Connection c = DBConnect.getConnection();
             Statement st = c.createStatement()) {
            st.execute(sql);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Lấy danh sách tất cả khách hàng
    public List<KhachHang> getAll() {
        List<KhachHang> list = new ArrayList<>();
        String sql = "SELECT * FROM khach_hang";
        try (Connection c = DBConnect.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new KhachHang(
                        rs.getInt("ma_kh"),
                        rs.getString("ho_ten"),
                        rs.getString("so_dt"),
                        rs.getDouble("tien_co")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Thêm khách hàng mới
    public void insert(KhachHang kh) {
        String sql = "INSERT INTO khach_hang(ho_ten, so_dt, tien_co) VALUES(?,?,?)";
        try (Connection c = DBConnect.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, kh.getHoTen());
            ps.setString(2, kh.getSoDT());
            ps.setDouble(3, kh.getTienCo());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Xóa khách hàng theo mã
    public void delete(int maKH) {
        String sql = "DELETE FROM khach_hang WHERE ma_kh=?";
        try (Connection c = DBConnect.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, maKH);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Cập nhật thông tin khách hàng
    public void update(KhachHang kh) {
        String sql = "UPDATE khach_hang SET ho_ten=?, so_dt=?, tien_co=? WHERE ma_kh=?";
        try (Connection c = DBConnect.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, kh.getHoTen());
            ps.setString(2, kh.getSoDT());
            ps.setDouble(3, kh.getTienCo());
            ps.setInt(4, kh.getMaKH());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
