package dao;

import model.DanhSachMuaHang;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DanhSachMuaHangDAO {

    public DanhSachMuaHangDAO() {
        createTableIfNotExists();
    }

    private void createTableIfNotExists() {
        String sql = """
            CREATE TABLE IF NOT EXISTS danh_sach_mua_hang (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ma_kh INTEGER NOT NULL,
                ma_mh INTEGER NOT NULL,
                so_luong INTEGER NOT NULL,
                thanh_tien REAL NOT NULL,
                FOREIGN KEY(ma_kh) REFERENCES khach_hang(ma_kh),
                FOREIGN KEY(ma_mh) REFERENCES mat_hang(ma_mh)
            )
        """;

        try (Connection c = DBConnect.getConnection();
             Statement st = c.createStatement()) {
            st.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<DanhSachMuaHang> getAll() {
        List<DanhSachMuaHang> list = new ArrayList<>();
        String sql = "SELECT ma_kh, ma_mh, so_luong, thanh_tien FROM danh_sach_mua_hang";

        try (Connection c = DBConnect.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new DanhSachMuaHang(
                        rs.getInt("ma_kh"),
                        rs.getInt("ma_mh"),
                        rs.getInt("so_luong"),
                        rs.getDouble("thanh_tien")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public void insert(DanhSachMuaHang dsmh) {
        String sql = "INSERT INTO danh_sach_mua_hang(ma_kh, ma_mh, so_luong, thanh_tien) VALUES(?,?,?,?)";
        try (Connection c = DBConnect.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, dsmh.getMaKH());
            ps.setInt(2, dsmh.getMaMH());
            ps.setInt(3, dsmh.getSoLuong());
            ps.setDouble(4, dsmh.getThanhTien());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete(int maKH, int maMH) {
        String sql = "DELETE FROM danh_sach_mua_hang WHERE ma_kh=? AND ma_mh=?";
        try (Connection c = DBConnect.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, maKH);
            ps.setInt(2, maMH);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
