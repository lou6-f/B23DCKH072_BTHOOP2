package dao;

import model.MatHang;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MatHangDAO {
    private final Connection conn;

    public MatHangDAO() {
        conn = DBConnect.getConnection();
        try (Statement st = conn.createStatement()) {
            st.execute("CREATE TABLE IF NOT EXISTS MatHang (" +
                    "maMH INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "tenMH TEXT," +
                    "nhomHang TEXT," +
                    "giaBan REAL" +
                    ")");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<MatHang> getAll() {
        List<MatHang> list = new ArrayList<>();
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM MatHang")) {
            while(rs.next()){
                list.add(new MatHang(
                        rs.getInt("maMH"),
                        rs.getString("tenMH"),
                        rs.getString("nhomHang"),
                        rs.getDouble("giaBan")
                ));
            }
        } catch(SQLException e) { e.printStackTrace(); }
        return list;
    }

    public void insert(MatHang mh){
        String sql = "INSERT INTO MatHang(tenMH, nhomHang, giaBan) VALUES(?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, mh.getTenMH());
            ps.setString(2, mh.getNhomHang());
            ps.setDouble(3, mh.getGiaBan());
            ps.executeUpdate();
        } catch(SQLException e){ e.printStackTrace(); }
    }

    public void update(MatHang mh){
        String sql = "UPDATE MatHang SET tenMH=?, nhomHang=?, giaBan=? WHERE maMH=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setString(1, mh.getTenMH());
            ps.setString(2, mh.getNhomHang());
            ps.setDouble(3, mh.getGiaBan());
            ps.setInt(4, mh.getMaMH());
            ps.executeUpdate();
        } catch(SQLException e){ e.printStackTrace(); }
    }

    public void delete(int maMH){
        String sql = "DELETE FROM MatHang WHERE maMH=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setInt(1, maMH);
            ps.executeUpdate();
        } catch(SQLException e){ e.printStackTrace(); }
    }
}
