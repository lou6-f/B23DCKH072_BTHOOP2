package model;

public class DanhSachMuaHang {
    private int maKH;
    private int maMH;
    private int soLuong;
    private double thanhTien;

    public DanhSachMuaHang(int maKH, int maMH, int soLuong, double thanhTien) {
        this.maKH = maKH;
        this.maMH = maMH;
        this.soLuong = soLuong;
        this.thanhTien = thanhTien;
    }

    public int getMaKH() { return maKH; }
    public int getMaMH() { return maMH; }
    public int getSoLuong() { return soLuong; }
    public double getThanhTien() { return thanhTien; }
}
