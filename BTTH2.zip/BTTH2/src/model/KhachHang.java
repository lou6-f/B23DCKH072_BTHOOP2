package model;

public class KhachHang {
    private int maKH;
    private String hoTen;
    private String soDT;
    private double tienCo;

    public KhachHang(int maKH, String hoTen, String soDT, double tienCo) {
        this.maKH = maKH;
        this.hoTen = hoTen;
        this.soDT = soDT;
        this.tienCo = tienCo;
    }

    public int getMaKH() { return maKH; }
    public String getHoTen() { return hoTen; }
    public String getSoDT() { return soDT; }
    public double getTienCo() { return tienCo; }

    public void setHoTen(String hoTen) { this.hoTen = hoTen; }
    public void setSoDT(String soDT) { this.soDT = soDT; }
    public void setTienCo(double tienCo) { this.tienCo = tienCo; }
}
