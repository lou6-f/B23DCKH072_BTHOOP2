package model;

public class MatHang {
    private int maMH;          
    private String tenMH;      
    private String nhomHang;   
    private double giaBan;     

    public MatHang() {}

    public MatHang(int maMH, String tenMH, String nhomHang, double giaBan) {
        this.maMH = maMH;
        this.tenMH = tenMH;
        this.nhomHang = nhomHang;
        this.giaBan = giaBan;
    }

    // Getter & Setter
    public int getMaMH() { return maMH; }
    public void setMaMH(int maMH) { this.maMH = maMH; }

    public String getTenMH() { return tenMH; }
    public void setTenMH(String tenMH) { this.tenMH = tenMH; }

    public String getNhomHang() { return nhomHang; }
    public void setNhomHang(String nhomHang) { this.nhomHang = nhomHang; }

    public double getGiaBan() { return giaBan; }
    public void setGiaBan(double giaBan) { this.giaBan = giaBan; }
}
