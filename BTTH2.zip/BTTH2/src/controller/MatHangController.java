package controller;

import view.MatHangFrame;
import dao.MatHangDAO;
import model.MatHang;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;

public class MatHangController {
    private final MatHangFrame view;
    private final MatHangDAO dao = new MatHangDAO();

    public MatHangController(MatHangFrame view){
        this.view = view;
        loadTable();

        view.btnThem.addActionListener(e -> them());
        view.btnSua.addActionListener(e -> sua());
    }

    private void loadTable(){
        String[] cols = {"Mã MH","Tên MH","Nhóm hàng","Giá bán"};
        DefaultTableModel model = new DefaultTableModel(cols,0);
        for(MatHang mh: dao.getAll()){
            model.addRow(new Object[]{mh.getMaMH(), mh.getTenMH(), mh.getNhomHang(), mh.getGiaBan()});
        }
        view.table.setModel(model);
    }

    private void them(){
        String ten = view.tfTenMH.getText().trim();
        String nhom = (String) view.cbNhomHang.getSelectedItem();
        String giaStr = view.tfGiaBan.getText().trim();

        if(ten.isEmpty() || nhom.isEmpty() || giaStr.isEmpty()){
            JOptionPane.showMessageDialog(view,"Nhập đủ thông tin!");
            return;
        }

        try{
            double gia = Double.parseDouble(giaStr);
            MatHang mh = new MatHang(0, ten, nhom, gia);
            dao.insert(mh);
            loadTable();
        } catch(Exception e){
            JOptionPane.showMessageDialog(view,"Giá bán phải là số!");
        }
    }

    private void sua(){
        int row = view.table.getSelectedRow();
        if(row<0){
            JOptionPane.showMessageDialog(view,"Chọn dòng cần sửa");
            return;
        }

        int maMH = (int)view.table.getValueAt(row,0);
        String ten = view.tfTenMH.getText().trim();
        String nhom = (String) view.cbNhomHang.getSelectedItem();
        String giaStr = view.tfGiaBan.getText().trim();

        if(ten.isEmpty() || nhom.isEmpty() || giaStr.isEmpty()){
            JOptionPane.showMessageDialog(view,"Nhập đủ thông tin!");
            return;
        }

        try{
            double gia = Double.parseDouble(giaStr);
            MatHang mh = new MatHang(maMH, ten, nhom, gia);
            dao.update(mh);
            loadTable();
        } catch(Exception e){
            JOptionPane.showMessageDialog(view,"Giá bán phải là số!");
        }
    }
}
