package controller;

import view.KhachHangFrame;
import dao.KhachHangDAO;
import model.KhachHang;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class KhachHangController {
    private final KhachHangFrame view;
    private final KhachHangDAO dao = new KhachHangDAO();

    public KhachHangController(KhachHangFrame view){
        this.view = view;
        loadTable();

        view.btnThem.addActionListener(e->them());
        view.btnXoa.addActionListener(e->xoa());
    }

    private void loadTable(){
        String[] cols = {"Mã KH","Họ tên","SĐT","Tiền có"};
        DefaultTableModel model = new DefaultTableModel(cols,0);
        for(KhachHang kh: dao.getAll()){
            model.addRow(new Object[]{kh.getMaKH(),kh.getHoTen(),kh.getSoDT(),kh.getTienCo()});
        }
        view.table.setModel(model);
    }

    private void them(){
        String hoTen = view.tfHoTen.getText().trim();
        String soDT = view.tfSoDT.getText().trim();
        String tienStr = view.tfTienCo.getText().trim();
        if(hoTen.isEmpty()||soDT.isEmpty()||tienStr.isEmpty()){
            JOptionPane.showMessageDialog(view,"Nhập đủ thông tin!");
            return;
        }
        try{
            double tien = Double.parseDouble(tienStr);
            KhachHang kh = new KhachHang(0,hoTen,soDT,tien);
            dao.insert(kh);
            loadTable();
        } catch(Exception e){
            JOptionPane.showMessageDialog(view,"Tiền phải là số!");
        }
    }

    private void xoa(){
        int row = view.table.getSelectedRow();
        if(row<0){ JOptionPane.showMessageDialog(view,"Chọn dòng cần xóa"); return; }
        int maKH = (int)view.table.getValueAt(row,0);
        dao.delete(maKH);
        loadTable();
    }
}
