package controller;

import view.DanhSachMuaHangFrame;
import dao.DanhSachMuaHangDAO;
import dao.MatHangDAO;
import dao.KhachHangDAO;
import model.DanhSachMuaHang;
import model.MatHang;
import model.KhachHang;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.*;

public class DanhSachMuaHangController {
    private final DanhSachMuaHangFrame view;
    private final DanhSachMuaHangDAO dao = new DanhSachMuaHangDAO();
    private final MatHangDAO mhDao = new MatHangDAO();
    private final KhachHangDAO khDao = new KhachHangDAO();

    public DanhSachMuaHangController(DanhSachMuaHangFrame view){
        this.view = view;
        loadTable();

        view.btnThem.addActionListener(e->them());
        view.btnXoa.addActionListener(e->xoa());
        view.cbSapXep.addActionListener(e->sortTable());
    }

    private void loadTable(){
        String[] cols = {"Mã KH","Mã MH","Số lượng","Thành tiền"};
        DefaultTableModel model = new DefaultTableModel(cols,0);
        for(DanhSachMuaHang ds: dao.getAll()){
            model.addRow(new Object[]{ds.getMaKH(),ds.getMaMH(),ds.getSoLuong(),ds.getThanhTien()});
        }
        view.table.setModel(model);
    }

    private void them(){
        try{
            int maKH = Integer.parseInt(view.tfMaKH.getText().trim());
            int maMH = Integer.parseInt(view.tfMaMH.getText().trim());
            int soLuong = Integer.parseInt(view.tfSoLuong.getText().trim());

            KhachHang kh = khDao.getAll().stream().filter(k->k.getMaKH()==maKH).findFirst().orElse(null);
            MatHang mh = mhDao.getAll().stream().filter(m->m.getMaMH()==maMH).findFirst().orElse(null);
            if(kh==null||mh==null){
                JOptionPane.showMessageDialog(view,"Mã KH hoặc MH không tồn tại!");
                return;
            }

            double thanhTien = soLuong*mh.getGiaBan();
            if(thanhTien>kh.getTienCo()){
                JOptionPane.showMessageDialog(view,"Số tiền vượt khả năng của khách!");
                return;
            }

            for(DanhSachMuaHang ds: dao.getAll()){
                if(ds.getMaKH()==maKH && ds.getMaMH()==maMH){
                    JOptionPane.showMessageDialog(view,"Khách này đã mua mặt hàng này rồi!");
                    return;
                }
            }

            dao.insert(new DanhSachMuaHang(maKH, maMH, soLuong, thanhTien));
            loadTable();
        } catch(Exception e){
            JOptionPane.showMessageDialog(view,"Dữ liệu nhập không hợp lệ!");
        }
    }

    private void xoa(){
        JOptionPane.showMessageDialog(view,"Chức năng xóa có thể triển khai trong DAO");
    }

    private void sortTable(){
        String opt = (String)view.cbSapXep.getSelectedItem();
        List<DanhSachMuaHang> list = dao.getAll();
        if(opt.equals("Theo họ tên khách")){
            Map<Integer,String> map = new HashMap<>();
            for(KhachHang kh: khDao.getAll()) map.put(kh.getMaKH(),kh.getHoTen());
            list.sort(Comparator.comparing(ds->map.get(ds.getMaKH())));
        } else if(opt.equals("Theo số lượng")){
            list.sort(Comparator.comparing(DanhSachMuaHang::getSoLuong).reversed());
        }

        String[] cols = {"Mã KH","Mã MH","Số lượng","Thành tiền"};
        DefaultTableModel model = new DefaultTableModel(cols,0);
        for(DanhSachMuaHang ds: list){
            model.addRow(new Object[]{ds.getMaKH(),ds.getMaMH(),ds.getSoLuong(),ds.getThanhTien()});
        }
        view.table.setModel(model);
    }
}
