package app;

import javax.swing.*;
import view.MatHangFrame;
import view.KhachHangFrame;
import view.DanhSachMuaHangFrame;

public class App {
    public static void main(String[] args) {
        // Đặt Look & Feel giống hệ thống
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch(Exception e){ e.printStackTrace(); }

        SwingUtilities.invokeLater(() -> {
            // Frame quản lý Mặt hàng
            MatHangFrame mhFrame = new MatHangFrame();
            mhFrame.setLocation(100,100);
            mhFrame.setVisible(true);

            // Frame quản lý Khách hàng
            KhachHangFrame khFrame = new KhachHangFrame();
            khFrame.setLocation(750,100);
            khFrame.setVisible(true);

            // Frame Danh sách mua hàng
            DanhSachMuaHangFrame dsFrame = new DanhSachMuaHangFrame();
            dsFrame.setLocation(400,550);
            dsFrame.setVisible(true);
        });
    }
}
