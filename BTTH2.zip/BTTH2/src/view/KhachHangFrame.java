package view;

import controller.KhachHangController;
import javax.swing.*;

public class KhachHangFrame extends JFrame {
    public JTextField tfMaKH, tfHoTen, tfSoDT, tfTienCo;
    public JButton btnThem, btnXoa;
    public JTable table;

    public KhachHangFrame() {
        setTitle("Quản lý Khách hàng");
        setSize(700,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Mã KH (tự động tăng)
        JLabel lbMa = new JLabel("Mã KH:");
        lbMa.setBounds(20,20,80,25);
        add(lbMa);
        tfMaKH = new JTextField();
        tfMaKH.setBounds(100,20,100,25);
        tfMaKH.setEditable(false);
        add(tfMaKH);

        // Họ tên
        JLabel lbHoTen = new JLabel("Họ tên:");
        lbHoTen.setBounds(220,20,80,25);
        add(lbHoTen);
        tfHoTen = new JTextField();
        tfHoTen.setBounds(300,20,150,25);
        add(tfHoTen);

        // Số điện thoại
        JLabel lbSDT = new JLabel("Số ĐT:");
        lbSDT.setBounds(20,60,80,25);
        add(lbSDT);
        tfSoDT = new JTextField();
        tfSoDT.setBounds(100,60,150,25);
        add(tfSoDT);

        // Tiền có
        JLabel lbTien = new JLabel("Tiền có:");
        lbTien.setBounds(300,60,80,25);
        add(lbTien);
        tfTienCo = new JTextField();
        tfTienCo.setBounds(380,60,100,25);
        add(tfTienCo);

        // Nút thêm, xóa
        btnThem = new JButton("Thêm");
        btnThem.setBounds(500,20,80,25);
        add(btnThem);

        btnXoa = new JButton("Xóa");
        btnXoa.setBounds(500,60,80,25);
        add(btnXoa);

        // Bảng hiển thị dữ liệu
        table = new JTable();
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20,100,650,350);
        add(sp);

        // Gắn controller
        new KhachHangController(this);
    }
}
