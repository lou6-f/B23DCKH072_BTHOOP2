package view;

import controller.MatHangController;
import javax.swing.*;

public class MatHangFrame extends JFrame {
    public JTextField tfMaMH, tfTenMH, tfGiaBan;
    public JComboBox<String> cbNhomHang;
    public JButton btnThem, btnSua;
    public JTable table;

    public MatHangFrame() {
        setTitle("Quản lý Mặt hàng");
        setSize(700,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Mã mặt hàng (tự động tăng, không nhập)
        JLabel lbMa = new JLabel("Mã MH:");
        lbMa.setBounds(20,20,80,25);
        add(lbMa);
        tfMaMH = new JTextField();
        tfMaMH.setBounds(100,20,100,25);
        tfMaMH.setEditable(false); // không cho người dùng nhập
        add(tfMaMH);

        // Tên mặt hàng
        JLabel lbTen = new JLabel("Tên MH:");
        lbTen.setBounds(220,20,80,25);
        add(lbTen);
        tfTenMH = new JTextField();
        tfTenMH.setBounds(300,20,150,25);
        add(tfTenMH);

        // Nhóm hàng
        JLabel lbNhom = new JLabel("Nhóm hàng:");
        lbNhom.setBounds(20,60,80,25);
        add(lbNhom);
        cbNhomHang = new JComboBox<>(new String[]{
            "Hàng thời trang",
            "Hàng tiêu dùng",
            "Hàng điện máy",
            "Hàng gia dụng"
        });
        cbNhomHang.setBounds(100,60,150,25);
        add(cbNhomHang);

        // Giá bán
        JLabel lbGia = new JLabel("Giá bán:");
        lbGia.setBounds(300,60,80,25);
        add(lbGia);
        tfGiaBan = new JTextField();
        tfGiaBan.setBounds(380,60,100,25);
        add(tfGiaBan);

        // Nút thêm, sửa
        btnThem = new JButton("Thêm");
        btnThem.setBounds(500,20,80,25);
        add(btnThem);

        btnSua = new JButton("Sửa");
        btnSua.setBounds(500,60,80,25);
        add(btnSua);

        // Bảng hiển thị dữ liệu
        table = new JTable();
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20,100,650,350);
        add(sp);

        // Gắn controller
        new MatHangController(this);
    }
}
