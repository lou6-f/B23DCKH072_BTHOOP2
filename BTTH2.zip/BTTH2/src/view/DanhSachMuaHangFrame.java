package view;

import controller.DanhSachMuaHangController;
import javax.swing.*;

public class DanhSachMuaHangFrame extends JFrame {
    public JTextField tfMaKH, tfMaMH, tfSoLuong, tfThanhTien;
    public JButton btnThem, btnXoa;
    public JTable table;
    public JComboBox<String> cbSapXep;

    public DanhSachMuaHangFrame() {
        setTitle("Danh sách mua hàng");
        setSize(700,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel lb1 = new JLabel("Mã KH:");
        lb1.setBounds(20,20,80,25);
        add(lb1);
        tfMaKH = new JTextField();
        tfMaKH.setBounds(100,20,100,25);
        add(tfMaKH);

        JLabel lb2 = new JLabel("Mã MH:");
        lb2.setBounds(220,20,80,25);
        add(lb2);
        tfMaMH = new JTextField();
        tfMaMH.setBounds(300,20,100,25);
        add(tfMaMH);

        JLabel lb3 = new JLabel("Số lượng:");
        lb3.setBounds(420,20,80,25);
        add(lb3);
        tfSoLuong = new JTextField();
        tfSoLuong.setBounds(500,20,100,25);
        add(tfSoLuong);

        JLabel lb4 = new JLabel("Thành tiền:");
        lb4.setBounds(20,60,80,25);
        add(lb4);
        tfThanhTien = new JTextField();
        tfThanhTien.setBounds(100,60,100,25);
        tfThanhTien.setEditable(false); // tính tự động
        add(tfThanhTien);

        btnThem = new JButton("Thêm");
        btnThem.setBounds(220,60,80,25);
        add(btnThem);

        btnXoa = new JButton("Xóa");
        btnXoa.setBounds(320,60,80,25);
        add(btnXoa);

        cbSapXep = new JComboBox<>(new String[]{"Theo họ tên khách", "Theo số lượng"});
        cbSapXep.setBounds(420,60,180,25);
        add(cbSapXep);

        table = new JTable();
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20,100,650,350);
        add(sp);

        // Gắn controller
        new DanhSachMuaHangController(this);
    }
}
